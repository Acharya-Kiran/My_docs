#!/bin/sh

echo "Pinging $host..."
ping -c 5 $host