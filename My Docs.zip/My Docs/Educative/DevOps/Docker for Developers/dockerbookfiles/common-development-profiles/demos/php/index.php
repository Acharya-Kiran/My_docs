<h1>Hello !</h1>
<p>This page is served by PHP</p>
<p>Try our <a href="/v1/square/4">multiply API</a>.</p>