from functools import cmp_to_key

def compare(s1, s2):
    i, j = 0, 0
    while i<len(s1) or j<len(s2):
        if i == len(s1):
            i -= 1
        if j == len(s2):
            j -= 1
        if s1[i] < s2[j]:
            return 1
        elif s1[i] > s2[j]:
            return -1
        i += 1
        j += 1
    return 0

l = ['9', '67', '78', '89', '92']
l = [''.join(sorted(val))[::-1] for val in l]
l_ = sorted(l, key=cmp_to_key(compare))
print(l)
print(l_)
print(''.join(l_))

# Note : 
# return a negative value (< 0) when the left item should be sorted before the right item
# return a positive value (> 0) when the left item should be sorted after the right item
# return 0 when both the left and the right item have the same weight and should be ordered "equally" without precedence